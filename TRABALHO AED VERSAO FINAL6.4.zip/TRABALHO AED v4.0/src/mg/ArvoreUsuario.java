package mg;
public class ArvoreUsuario {
    public ChaveUsuario raiz;
    public ArvoreUsuario esquerda, direita;
    public int bal;



    public ArvoreUsuario(){
        this.raiz=null;
        this.direita=this.esquerda=null;
        this.bal = 0;
    }

    public void inserir (ChaveUsuario novo){
        if(raiz==null)
            raiz=novo;
        else{
            if(novo.compareTo(raiz)<0) {
                if (esquerda == null)
                    esquerda = new ArvoreUsuario();
                esquerda.inserir(novo);

            }
            else{
                if (direita == null)
                    direita = new ArvoreUsuario();
                direita.inserir(novo);

            }

        }
    }

    public ChaveUsuario buscar(String cpf){

        if (this.raiz != null) {
            if (this.raiz.chave.compareTo(cpf) == 0) {
                return this.raiz;
            } else {
                if (this.raiz.chave.compareTo(cpf) > 0) {
                    if (this.esquerda == null)
                        return null;
                    else
                        return this.esquerda.buscar(cpf);
                } else {
                    if (this.direita == null)
                        return null;
                    else
                        return this.direita.buscar(cpf);
                }
            }
        } else {
            return null;
        }
    }

    public ArvoreUsuario remover(String cpf){

        // o elemento buscado n�o tem subarvores
        if (this.raiz.chave.compareTo(cpf)==0){

            if (this.esquerda == null && this.direita == null){
                return null;

            }
            // com subarvores
            else{
                // s� tem filhos � esquerda (acaba sobrando a sub-�rvore da esquerda)
                if (this.esquerda != null && this.direita == null){
                    return this.esquerda;
                }
                // subarvore apenas � direita
                else if (this.direita != null && this.esquerda == null){
                    return this.direita;
                }
                // subarvores esquerda e direita

                else{
                    ArvoreUsuario aux = this.direita;
                    while (aux.esquerda != null){
                        aux = aux.esquerda;
                    }
                    this.raiz=aux.raiz;  // troco os valores
                    aux.raiz.chave=cpf;
                    // fa�o a �rvore da direita receber a remo��o do elemento (que vai estar numa folha)
                    this.direita = direita.remover(cpf);
                }
            }
        }
        else{
            // o elemento � menor, sera removido na esquerda
            if (this.raiz.chave.compareTo(cpf)>0 ){
                if (this.esquerda != null){
                    this.esquerda = this.esquerda.remover(cpf);
                }
            }
            // o elemento � maior, ser� removido na direita
            else if (this.raiz.chave.compareTo(cpf)<0){
                if (this.direita != null){
                    this.direita = this.direita.remover(cpf);
                }
            }

        }
        return this;

    }

    public String printArvore(int level){
        String str = this.toString()+"\n";
        for (int i=0; i<level; i++){
            str += "\t";
        }
        if (this.esquerda != null){
            str += "+-ESQ: "+this.esquerda.printArvore(level + 1);
        }
        else{
            str += "+-ESQ: NULL";
        }
        str += "\n";
        for (int i=0; i<level; i++){
            str += "\t";
        }
        if (this.direita != null){

            str += "+-DIR: "+this.direita.printArvore(level + 1);
        }
        else{
            str += "+-DIR: NULL";
        }
        str += "\n";
        return str;
    }
    public String toString(){
        return "["+this.raiz.chave+"] ("+this.bal+")";
    }

    public String emOrdem(){
        String aux="";
        if(esquerda!=null)
            aux+= esquerda.emOrdem();
        aux +=raiz.valor.toString();
        if(direita!=null)
            aux+= direita.emOrdem();
        return aux;
    }

    public String preOrdem(){
        String aux="";
        aux +=raiz.valor.toString();
        if(esquerda!=null)
            aux+= esquerda.preOrdem();
        if(direita!=null)
            aux+= direita.preOrdem();
        return aux;
    }

    public String posOrdem(){
        String aux="";
        if(esquerda!=null)
            aux+= esquerda.posOrdem();
        if(direita!=null)
            aux+= direita.posOrdem();
        aux +=raiz.valor.toString();
        return aux;
    }
}







