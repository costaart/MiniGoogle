package mg;

public class ChaveUsuario {
    String chave;
    Usuario valor;

    public ChaveUsuario(Usuario usuario){
        this.chave=usuario.cpf;
        this.valor=usuario;
    }

    public int compareTo(ChaveUsuario outra) {
        if(this.chave.compareTo(outra.chave)<0)
            return -1;
        else if(this.chave.compareTo(outra.chave)>0)
            return 1;
        else return 0;
    }
}
