package mg;

public class Documento {
    public int idDocumento;        //ser� em ordem crescente (id00, 01, 02...)
    public String tituloDocumento;
    public String arquivoDocumento;

    //metodo construdor da classe.
    public Documento(int idDoc, String tituloDoc, String arqDoc) {
        this.idDocumento = idDoc;
        this.tituloDocumento = tituloDoc;
        this.arquivoDocumento = arqDoc;

    }
}