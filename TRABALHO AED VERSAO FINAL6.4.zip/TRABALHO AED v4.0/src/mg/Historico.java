package mg;

import java.util.ArrayList;

public class Historico {
    ArrayList<String> palavrasPesquisadas = new ArrayList<>();
    String usuario;
}
