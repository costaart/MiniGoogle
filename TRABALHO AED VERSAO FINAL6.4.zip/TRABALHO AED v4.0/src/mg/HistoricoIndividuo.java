package mg;

import java.io.File;

public class HistoricoIndividuo {
	    public File dadoUsuario;
	    public HistoricoIndividuo proximo;

	    //metodo construtor
	    public HistoricoIndividuo (File historico){
	        dadoUsuario = historico;
	        proximo = null;
	    }
	    //metodo equals para localizar usuario
	    public boolean equals(Object obj){
	        String localiza = (String)obj;

	        return dadoUsuario.equals(localiza);
	    }
}
