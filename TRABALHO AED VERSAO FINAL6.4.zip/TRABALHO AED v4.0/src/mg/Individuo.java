package mg;

/**
 * classe Individuo, como elemento da estrutura de dados lista;
 * @dadoUsuario cont�m dados do Usuario
 * @proximo ponteiro do proximo elemento Individuo da lista;
 */

public class Individuo {
    public int registroPalavra;
    public Individuo proximo;

    //metodo construtor
    public Individuo (int registro){
        registroPalavra=registro;
        proximo=null;
    }
}
