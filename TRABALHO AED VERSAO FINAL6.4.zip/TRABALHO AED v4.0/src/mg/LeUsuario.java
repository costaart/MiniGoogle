package mg;

import com.sun.source.tree.ContinueTree;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
/*  TRABALHO DA DISCIPLINA DE ALGORITMO E ESTRUTURA DE DADOS
 *  - Tema: Busca em Documentos
 *  - Integrantes: Arthur Almeida Costa
 *                 Juan Gabriel dos Santos Alves
 *                 Roselmiriam Rodrigues dos Santos
 **/

public class LeUsuario {
    public static int opcao;
    public static String pesquisa;
    public static String log;
    public static boolean usuarioLogado = false;
    static ArvoreUsuario arvoreUsuario = new ArvoreUsuario();
    static ArvorePalavra inserirPalavra = new ArvorePalavra();
    public static ArrayList<Documento> todosDocumentos = new ArrayList<>();
    public static ArrayList<String> Listastopwords = new ArrayList<>();

    public static void LerStopwords() throws FileNotFoundException {
        Scanner stopw = new Scanner(new File("DOCUMENTOS\\stopwords.txt"));
        StringTokenizer parsersw;
        String tokenAuxsw;
        while (stopw.hasNextLine()) {
            String linha = stopw.nextLine();
            parsersw = new StringTokenizer(linha);
            while (parsersw.hasMoreTokens()) {
                tokenAuxsw = parsersw.nextToken();
                String aux = tokenAuxsw.toUpperCase();
                Listastopwords.add(aux);
            }
        }
        stopw.close();
    }

    public static boolean leArvore(String cpf) {
        if (arvoreUsuario.buscar(cpf) == null)
            return false;
        else
            return true;
    }


    public static void inserirUsuarioArvore(String infoUsuario) throws IOException {

        FileWriter gravador = new FileWriter("DOCUMENTOS\\dadosUsuario.txt", true);
        gravador.write("\n" + infoUsuario);
        gravador.close();
        String[] dadosUsuario = infoUsuario.split(";");
        ChaveUsuario usuarioInserir = new ChaveUsuario(new Usuario(dadosUsuario[0], dadosUsuario[1], dadosUsuario[2], dadosUsuario[3]));
        arvoreUsuario.inserir(usuarioInserir);
    }

    public static void carregarArvore() throws FileNotFoundException {
        Scanner leitor = new Scanner(new File("DOCUMENTOS\\dadosUsuario.txt"));
        while (leitor.hasNextLine()) {
            String usuarioLinha = leitor.nextLine();
            String[] dados = usuarioLinha.split(";");
            ChaveUsuario raiz = new ChaveUsuario(new Usuario(dados[0], dados[1], dados[2], dados[3]));
            arvoreUsuario.inserir(raiz);
        }
        leitor.close();
    }

    public static boolean verificarStopwords(String palavra) {
        ArrayList<String> aux = new ArrayList<>();
        aux = Listastopwords;
        if (aux.contains(palavra))
            return true;
        else
            return false;
    }

    public static void formatarDadosBusca(String palavraBuscada) throws IOException {
        FileWriter formatar = new FileWriter("D:\\Area de trabaho\\TRABALHO AED v4.0\\DOCUMENTOS\\dadosBuscaUsuario.txt", true);
        formatar.write("\n" + log + ";" + palavraBuscada);
        formatar.close();
    }

    public static ArvoreUsuario removerUsuario() throws IOException {
        Scanner entrada = new Scanner(System.in);
        String cpf;
        System.out.println("Informe o cpf: ");
        cpf = entrada.nextLine();
        ArvoreUsuario atualizada = arvoreUsuario;
        ChaveUsuario buscado = atualizada.buscar(cpf);
        if (buscado != null) {
            atualizada = atualizada.remover(cpf);
            String arvoreNova = atualizada.preOrdem();
            FileWriter gravador = new FileWriter("DOCUMENTOS\\dadosUsuario.txt");
            gravador.write(arvoreNova);
            gravador.close();
        } else
            return null;
        return atualizada;
    }

    public static String formatarCPF(String cpf) {
        try {
            StringBuilder formatarCpf = new StringBuilder(cpf);
            formatarCpf.insert(9, '-');
            return formatarCpf.toString();
        } catch (StringIndexOutOfBoundsException formatarCpf) {
            System.out.println("ERRO, CPF inv�lido.");
            return null;
        }
    }

    public static void cadastro() throws IOException, NumberFormatException {
        try {
            Scanner entrada = new Scanner(System.in);
            String cpf, nome, email, senha, novoUsuario;
            System.out.print("Informe o CPF: ");
            cpf = entrada.nextLine();
            long conferirExcecao = Long.parseLong(cpf);

            if (cpf.length() < 11 || cpf.length() > 11) {
                System.out.println("ERRO, CPF inv�lido.");
                cadastro();
            } else {
                cpf = formatarCPF(cpf);
                if (leArvore(cpf) == true) {
                    System.out.println("CPF j� cadastrado! Informe outro novamente.");
                    System.out.println(" ");
                    cadastro();
                } else {
                    System.out.print("Informe o nome: ");
                    nome = entrada.nextLine();
                    System.out.print("Informe o email: ");
                    email = entrada.nextLine();
                    System.out.print("Informe senha: ");
                    senha = entrada.nextLine();
                    novoUsuario = cpf + ";" + nome + ";" + email + ";" + senha;
                    inserirUsuarioArvore(novoUsuario);
                    System.out.println("Usu�rio cadastrado com sucesso!");
                }
            }
        } catch (NumberFormatException conferirExcecao) {
            System.out.println("ERRO, CPF inv�lido.");
            cadastro();
        }
    }

    public static void lerDocumentos() throws FileNotFoundException {
        try {
            String path = "D:\\Area de trabaho\\TRABALHO AED v4.0\\DOCUMENTOS\\TXT";
            File documentosSelecionados = new File(path);
            String[] NomeDocumentos = documentosSelecionados.list();
            int id = -1;
            for (String nome : NomeDocumentos) {
                id++;
                String caminho = path + "\\" + nome;
                Documento documento = new Documento(id, nome, caminho);
                todosDocumentos.add(documento);
            }

            Documento arquivos[] = (Documento[]) todosDocumentos.toArray(new Documento[0]);

            for (int i = 0; i < arquivos.length; i++) {
                Scanner arq = new Scanner(new File(arquivos[i].arquivoDocumento));
                StringTokenizer parser;
                String tokenAux;
                List<String> linhas = Files.readAllLines(Paths.get(arquivos[i].arquivoDocumento));
                for (String linha: linhas) {
                    parser = new StringTokenizer(linha);
                    while (parser.hasMoreTokens()) {
                        tokenAux = parser.nextToken();
                        inserirPalavraArvore(tokenAux, arquivos[i].idDocumento);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void inserirPalavraArvore(String palavraDocumento, int documento) {
        StringTokenizer parser;
        String tokenAux;
        parser = new StringTokenizer(palavraDocumento);
        while (parser.hasMoreTokens()) {
            Palavra palavra = new Palavra();
            tokenAux = parser.nextToken();
            palavra.caracteres = tokenAux.toUpperCase();
            palavra.registro.add(documento);
            String aux = filtrarString(palavra.caracteres);
            palavra.caracteres = aux;
            if (!verificarStopwords(aux) && !palavra.equals("")) {
                inserirPalavra.inserir(palavra);

            }
        }
    }

    public static String filtrarString(String caracteres) {
        String aux = caracteres.replaceAll(",", "").replaceAll(":", "")
                .replaceAll("\"", "").replace(".", "").replaceAll(";", "")
                .replaceAll("�", "").replaceAll("[?]", "").replaceAll("!", "")
                .replaceAll("\\s", "").replaceAll("[()]", "").replaceAll("[||]", "")
                .replaceAll("\\[", "").replaceAll("\\]", "").replace(" ", "")
                .replaceAll("�", "").replaceAll("�", "");
        return aux;
    }

    public static void buscarPalavra(String busca) {
        if (inserirPalavra.buscar(busca) != null) {
            ArrayList<Integer> auxiliar = new ArrayList<>();
            for (int registro : inserirPalavra.buscar(busca).item.registro) {
                auxiliar.add(registro);
            }

            Set<Integer> set = new HashSet<>(auxiliar);
            auxiliar.clear();
            auxiliar.addAll(set);

            for (int arquivo : auxiliar) {
                System.out.println("==============\nTITULO: " + todosDocumentos.get(arquivo).tituloDocumento);
                System.out.println("ID: " + todosDocumentos.get(arquivo).idDocumento);
            }
        } else
            System.out.println("\nPALAVRA N�O ENCONTRADA.");
    }

    public static void palavraPesquisa() throws FileNotFoundException {
        try {
            LerStopwords();
            lerDocumentos();
            Scanner entrada = new Scanner(System.in);
            System.out.print("Digite a palavra que deseja pesquisar: ");
            pesquisa = entrada.nextLine();
            formatarDadosBusca(pesquisa);
            buscarPalavra(pesquisa);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //metodo para exibir historico do usuario por data
    public static void historico() throws IOException {
        ArrayList<String> auxExibirHistorico = new ArrayList<>();
        auxExibirHistorico = getHistoricoUsuario();
        if (auxExibirHistorico.size() == 0) {
            System.out.println("\nVoc� ainda n�o pesquisou nenhuma palavra.\n");
        } else {
            System.out.println("PALAVRAS PESQUISADAS: ");
            System.out.println("-----------------------\n");
            for (String palavra : auxExibirHistorico) {
                System.out.println(palavra + "\n==============\n");
            }
        }
    }

    //Se o filtro for true, retorna o hist�rico sem palavras repetidas.
    public static ArrayList<String> getHistoricoUsuario() throws IOException {
        List<String> linhas = Files.readAllLines(Paths.get("D:\\Area de trabaho\\TRABALHO AED v4.0\\DOCUMENTOS\\dadosBuscaUsuario.txt"), Charset.defaultCharset());
        ArrayList<String> aux = new ArrayList<>();
        ArrayList<String> historico = new ArrayList<>();

        for (String linha: linhas) {
            String auxSplit[] = linha.split(";");
            if (auxSplit.length >= 2 ) {
                //Se linha conter CPF do usu�rio logado, armazena a palavra buscada em um Array auxiliar;
                if (linha.contains(log)) {
                    aux.add(auxSplit[1].toLowerCase());
                }
            }
        }

        for (String elemento: aux) {
            if (!historico.contains(elemento))
                historico.add(filtrarString(elemento));
        }

        //Retorna todas as palavras bucadas pelo usuario;
        return historico;
    }

    public static Usuario login() {
        Scanner entrada = new Scanner(System.in);
        String senha;
        System.out.print("CPF: ");
        log = entrada.nextLine();
        if (log.length() < 11 || log.length() > 11) {
            System.out.println("ERRO, CPF inv�lido.");
            login();
        } else {
            System.out.print("Senha: ");
            senha = entrada.nextLine();
            log = formatarCPF(log);
            ChaveUsuario fulano = arvoreUsuario.buscar(log);
            if (fulano != null && fulano.valor.cpf.equals(log) && fulano.valor.senha.equals(senha)) {
                usuarioLogado = true;
                return fulano.valor;
            } else
                return null;
        }
        return null;
    }

    public static void ordenaHistorico(ArrayList<String> historico) {
        String[] auxHistorico = historico.toArray(new String[0]);
        for (int i = 0; i < auxHistorico.length; i++) {
            for (int j = 0; j < auxHistorico.length - 1; j++) {
                if (auxHistorico[j].compareTo(auxHistorico[j + 1]) > 0) {
                    String aux = auxHistorico[j];
                    auxHistorico[j] = auxHistorico[j + 1];
                    auxHistorico[j + 1] = aux;
                }
            }
        }
        if (historico.size() == 0)
            System.out.println("\nVoc� ainda n�o pesquisou nenhuma palavra.\n");
        else {
            System.out.println("PALAVRAS PESQUISADAS: ");
            System.out.println("-----------------------\n");
            for (int i = 0; i < auxHistorico.length; i++) {
                System.out.println(auxHistorico[i] + "\n==============\n");
            }
        }
    }

    public static void converterArquivosUTF () throws FileNotFoundException, UnsupportedEncodingException {
        BufferedReader converterUTF = new BufferedReader(new InputStreamReader(new FileInputStream("D:\\Area de trabaho\\TRABALHO AED v4.0\\DOCUMENTOS\\dadosBuscaUsuario.txt"), "UTF-8"));
        String path = "D:\\Area de trabaho\\TRABALHO AED v4.0\\DOCUMENTOS\\TXT";
        File documentos = new File(path);
        String[] todosDocumentos = documentos.list();
        for (String documento: todosDocumentos) {
            String caminho = path + "\\" + documento;
            BufferedReader converterUTF2 = new BufferedReader(new InputStreamReader(new FileInputStream(caminho), "UTF-8"));
        }
    }

    public static void main(String[] args) throws Exception {
        //converterArquivosUTF();
        carregarArvore();
        Scanner entrada = new Scanner(System.in);
        System.out.println("=-=- PROGRAMA BUSCA EM DOCUMENTOS -=-=");
        System.out.println(" =====================================");
        System.out.print(" 1 - Fazer login;\n 2 - Fazer cadastro; \n 3 - Realizar busca em documentos; \n4 - Visualizar hist�rico de palavras pesquisadas;\n5 - Remover usuario;\n9 - Sair\n ===================================== \nEscolha a op��o: ");
        opcao = entrada.nextInt();
        while(opcao!=9) {
            switch (opcao) {
                case 1:
                    System.out.println(" - LOGIN -");
                    Usuario logado = login();
                    while (logado == null) {//enquanto n�o houver um usu�rio valido
                        System.out.println("Login ou senha inv�lidos. Tente novamente!:");
                        logado = login();
                    }
                    System.out.println("Login realizado com sucesso!");
                    System.out.println("Bem vindo(a) " + logado.nome + "!");
                    System.out.print("\nEscolha\n 3 - Realizar busca em documentos; \n 4 - Visualizar hist�rico de palavras pesquisadas; \n 9 - Sair;\n Informe a sua op��o: ");
                    opcao = entrada.nextInt();
                    break;
                case 2:
                    System.out.println(" - CADASTRO -");
                    cadastro();
                    System.out.println("\n 1- Fazer login; \n 3 - Realizar busca em documentos; \n 4 - Visualizar hist�rico de palavras pesquisadas; \n 9 - Sair;\nEscolha a op��o: ");
                    opcao = entrada.nextInt();
                    break;
                case 3:
                    if(usuarioLogado){
                        palavraPesquisa();
                        System.out.println("\nEscolha a op��o: \n 3 - Realizar busca em documentos \n 4 - Visualizar hist�rico de palavras pesquisadas; \n 9 - Sair;");
                        opcao = entrada.nextInt();
                    }
                    else {
                        System.out.println("Necessario login! Tecle 1 para realizar o login ou 9 para sair");
                        opcao = entrada.nextInt();
                    }
                    break;

                case 4:
                    if(usuarioLogado){
                        System.out.print("Escolha \n 1 - Exibi��o por data;\n 2 - Exibi��o por palavra; \n 3 - Voltar;\nop�ao: ");
                        int escolha = entrada.nextInt();
                        if(escolha == 1)
                            historico();
                        else if(escolha == 2)//ser� feito metodo para ordenacao do historico em ordem alfabetica

                            ordenaHistorico(getHistoricoUsuario());

                        else if(escolha == 3){
                            System.out.println("\n3 - Realizar busca em documentos; \n4 - Visualizar hist�rico de palavras pesquisadas; \n9 - Sair;\nEscolha a op��o: ");
                            opcao = entrada.nextInt();}
                    } else {
                        System.out.println("Necessario login! Tecle 1 para realizar o login ou 9 para sair");
                        opcao = entrada.nextInt();
                    }
                    break;

                case 5:
                    if(removerUsuario()!=null)
                        System.out.println("Usuario removido com sucesso!");
                    else
                        System.out.println("Usuario n�o localizado!");
                    System.out.println("\n3 - Realizar busca em documentos; \n4 - Visualizar hist�rico de palavras pesquisadas; \n9 - Sair;\nEscolha a op��o: ");
                    opcao = entrada.nextInt();
                    break;
                case 6:
                    System.out.print("Op��o: ");
                    opcao = entrada.nextInt();
                    break;
                case 9:
                    System.out.println("Obrigado por utilizar nosso software. Volte sempre!");
                    break;
            }
        }
    }
}
