package mg;
public class ListaHistorico {

    private static class No {
        public No prox; // pr�ximo n� na lista
        public Historico valor; // elemento (valor) armazenado na lista

        public No(Historico val) { //construtor do n� da lista
            valor = val;
            prox = null;
        }
    }

    private No inicio; //representa a cabe�a (in�cio) da lista

    public ListaHistorico() {   // construtor da lista
        inicio = null;
    }

    public boolean isEmpty() {
        return inicio == null;
    }

    public boolean busca(Historico elem) {
        for (No nodo = inicio; nodo != null; nodo = nodo.prox)
            if (elem == nodo.valor) return true; //econtrou o elemento
        return false;                     // n�o encontrou o elemento

    }

    public void insereInicio(Historico elem) { //insere no in�cio da lista
        No novoNo = new No(elem);
        novoNo.prox = inicio; //novoNo -> inicio antigo
        inicio = novoNo;      // inicio -> novoNo
    }

    public void removeInicio() { //elimina o primiro item da lista
        inicio = inicio.prox; // elimina o elemento e reposiciona o in�cio
    }

    public String exibeLista() {
        if (isEmpty()) return "Lista vazia\n"; //teste de lista vazia
        String str = "Lista Encadeada: ";
        for (No nodo = inicio; nodo != null; nodo = nodo.prox)
            str += " " + nodo.valor;
        return str + "\n";
    }
}