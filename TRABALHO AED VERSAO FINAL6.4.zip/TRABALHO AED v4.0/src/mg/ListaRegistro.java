package mg;

public class ListaRegistro {
    public Individuo primeiro;
    public Individuo ultimo;

    //metodo construtor

    public ListaRegistro(){
        primeiro=new Individuo(-1);
        ultimo=primeiro;
    }

    //metodo para inserir usuario no final da lista

    public void inserirRegistro(int registro){
        Individuo novo= new Individuo(registro); //criando um novo individuo
        ultimo.proximo = novo;
        ultimo = novo;
    }

    /*metodo para localizar usuario na lista.
    parametro String cpf do usuario*/

    public int localizarCpf(String cpf){
        Individuo aux = primeiro.proximo;
        while (aux!=null){
            if(aux.equals(cpf))
                return aux.registroPalavra;
            else aux=aux.proximo;
        }
        return -1;
    }

    public boolean vazia() {
        return (ultimo == primeiro);
    }

    //metodo para retirar usuario da lista
}


