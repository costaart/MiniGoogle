package mg;

public class No {
    public Palavra item;
    public No dir;
    public No esq;
}
