package mg;

import java.util.ArrayList;

public class Palavra {
    ArrayList<Integer> registro = new ArrayList<>();
    String caracteres;
}