package mg;

import javax.swing.*;
import java.io.File;
import java.util.Scanner;

public class Teste {

    public static void main(String[] args) {

    }
}
