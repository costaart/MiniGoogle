package mg;

/**
 * classe Usuario desenvolvida para o trabalho de Busca de documentos
 * @cpf String para o CPF do usu�rio que ira realizar a busca;
 * @nome String para o nome do usu�rio que ir� realizar a busca;
 * @login String para o login do usu�rio a ser criado quando do seu cadastro
 */

public class Usuario {
    public String cpf;
    public String nome;
    public String login;
    public String senha;


    //metodo construtor classe Usuario
    public Usuario(String id, String nome, String email, String senha){

        this.cpf=id;
        this.nome=nome;
        this.login=email;
        this.senha=senha;
    }
    //metodo toString para conversao em String dos dados do Usuario
    public String toString() {
        String aux = cpf + ";" +nome + ";" + login+";"+senha+"\r\n";
        return aux;
    }
    //metodo equals para localizar Usuario
    public boolean equals(Object obj) {
        String localiza = (String)obj;
        return this.cpf.equals(localiza) || this.login.equals(localiza) || this.senha.equals(localiza);


    }





}